<!DOCTYPE html>
<html lang="nl">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>EHabitz</title>
		<link href="<?php echo bloginfo('template_url');?>/css/owl.theme.css" rel="stylesheet" />
		<link href="<?php echo bloginfo('template_url');?>/css/owl.transitions.css" type="text/css" rel="stylesheet"/>
		<link href="<?php echo bloginfo('template_url');?>/css/owl.carousel.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/css/bootstrap-theme.min.css" type="type/css" />
		<!--<script src="<?php echo bloginfo('template_url');?>/js/jquery-1.11.3.min.js"></script>-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="<?php echo bloginfo('template_url');?>/js/owl.carousel.js"></script>
		<script src="<?php echo bloginfo('template_url');?>/js/bootstrap.min.js"></script>
		<link href="<?php echo bloginfo('template_url');?>/css/style.css" rel="stylesheet" />
		<link href="<?php echo bloginfo('template_url');?>/css/responce.css" rel="stylesheet" />
		<link href="<?php echo bloginfo('template_url');?>/css/lightbox.css" rel="stylesheet" />
		<link rel="shortcut icon" href="<?php bloginfo('template_url');?>/images/favicon.ico" type="image/x-icon">
		<script src="<?php echo bloginfo('template_url');?>/js/jquery.cookie.js"></script>
		<script defer src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.10.0/js/lightbox.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script type='text/javascript' src='https://maps.google.com/maps/api/js?key=AIzaSyA6HJ79KtwaKUPaDqSkiNgqlhaKvRJIDkM&#038;libraries=places&#038;ver=20161019'></script>
		<script type='text/javascript' src='https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js'></script>
		<script type="text/javascript">
			var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
		</script>
		
	</head>
	<body>
		<div class="full_content overons">
			<header>
				<div class="top_panel">
					<div class="container">
						<?php if ( ! dynamic_sidebar( 'sidebar-5' ) ) : ?>
						<?php
							the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php endif; // end sidebar widget area ?>
						<div class="langugeContainer" id="languageContainer">
						<span id="languageDropDown">Languages</span>
						<div id="translator" class="translate">
							<?php if ( ! dynamic_sidebar( 'sidebar-20' ) ) : ?>
							<?php
								the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
							?>
							<?php endif; // end sidebar widget area ?>
							<?php //echo do_shortcode('[gtranslate]'); ?>
						</div>
						</div>
					</div>
				</div>
				<div class="head_panel panel">
					<div class="head_menu">
						<div class="container">
							<div class="logo">
								<a href="<?php echo get_site_url();?>"><img src="<?php echo  get_template_directory_uri()?>/images/logo.png"></a>
							</div>
							<div class="icons">
								<div class="menu_open">
									<button class="OpenNav">&#9776;</button>
								</div>
								<div class="menu_close">
									<button class="CloseNav">&times;</button>
								</div>
							</div>
							<div class="menu">
								
								<?php wp_nav_menu( array(
									'menu_class' => 'list-inline',
									'theme_location' => 'primary',
									'menu_id'        => 'top-menu',
								) ); ?>
							</div>
							<div class="search">
								<a id="searchLink" href="<?php get_site_url();?>"  data-toggle="modal" data-target="#myModalSearch"><div class="searchicon"></div></a>
								<div class="modal fade" id="myModalSearch" role="dialog">
									<div class="modal-dialog pop">
										<!-- Modal content-->
										<div class="modal-content">
											<div class="search_bar">
												<?php get_search_form(); ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="page_heading container">
						<h1 id="breadCrumb">Home / </h1>
					</div>
				</div>
			</header>			