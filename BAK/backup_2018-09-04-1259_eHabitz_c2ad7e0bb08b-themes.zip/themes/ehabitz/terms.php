<?php
	/**
		* Template Name: terms Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); ?>
<div class="main_content my-page">
	<div class="container">
		<h1>Terms & Condition</h1>
		<?php echo apply_filters( 'the_content', get_post_field( 'post_content', get_option( 'page_for_posts' ) ) );?>
	</div>
</div>
<?php get_footer(); ?>