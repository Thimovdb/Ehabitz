<?php if (!defined('ABSPATH')) exit; ?>
<div data-columns="8">

    <span class="wpgmap_msg_error" style="width:80%;">

    </span>
    <!--all map tab-->
    <div class="wp-gmap-list">

        <div id="wpgmapembed_lialoy to...st">
            <?php
            $this->load_wpgmapembed_list();
            ?>
        </div>

    </div>
</div>