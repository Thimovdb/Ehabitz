<form class="form-group" role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<input id="searchTextBox" class="Myinput"type="text" name="s" placeholder="Search here..." autofocus>
	<input type="submit" class="buts" id="searchsubmit" value=""/>
</form>