<?php
function api()
{
	function lookupAddress($postcode, $houseNumber, $houseNumberAddition)
	{
		$serviceUrl = 'https://api.postcode.nl';
		$serviceKey = 'CdlS1uU4BhLrGntxdREgWCapuD25KYf25wkWZn8rmxd';
		$serviceSecret = 'LQ0SIyUj0RKzfnf2BPdifVIonNIYUP1NatpRUkgWiBh';
		$serviceShowcase = 'true';
		$serviceDebug = 'true' ;
		$extensionInfo = '';
		$extensionVersion = $extensionInfo ? (string)$extensionInfo->version : 'unknown';
		if (!$serviceUrl || !$serviceKey || !$serviceSecret)
		{
			return array('message' => ('Postcode.nl API is niet geconfigureerd.'));
		}
		// Check for SSL support in CURL, if connecting to `https`
		if (substr($serviceUrl, 0, 8) == 'https://')
		{
			$curlVersion = curl_version();
			if (!($curlVersion['features'] & CURL_VERSION_SSL))
			{
				return array('message' => ('Cannot connect to Postcode.nl API: Server is missing SSL (https) support for CURL.'));
			}
		}
		$url = $serviceUrl . '/rest/addresses/' . urlencode($postcode). '/'. urlencode($houseNumber) . '/'. urlencode($houseNumberAddition);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_USERPWD, $serviceKey .':'. $serviceSecret);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		//curl_setopt($ch, CURLOPT_USERAGENT, 'PostcodeNl_Api_MagentoPlugin/' . $extensionVersion .' '. $this->_getMagentoVersion());
		$jsonResponse = curl_exec($ch);
		$curlError = curl_error($ch);
		curl_close($ch);
		$response = json_decode($jsonResponse, true);
		$sendResponse = array();
		if ($serviceShowcase)
		$sendResponse['showcaseResponse'] = $response;
		if ($serviceDebug)
		{
			$modules = array();
			$sendResponse['debugInfo'] = array(
			'requestUrl' => $url,
			'rawResponse' => $jsonResponse,
			'parsedResponse' => $response,
			'curlError' => $curlError,
			'configuration' => array(
			'url' => $serviceUrl,
			'key' => $serviceKey,
			'secret' => substr($serviceSecret, 0, 6) .'[hidden]',
			'showcase' => $serviceShowcase,
			'debug' => $serviceDebug,
			),
			);
		}
		if (is_array($response) && isset($response['exceptionId']))
		{
			switch ($response['exceptionId'])
			{
				case 'PostcodeNl_Controller_Address_InvalidPostcodeException':
					$sendResponse['message'] = ('Ongeldig formaat postcode. Gebruik het volgende formaat 1234AB.');
					$sendResponse['messageTarget'] = 'postcode';
				break;
				case 'PostcodeNl_Service_PostcodeAddress_AddressNotFoundException':
					$sendResponse['message'] = ('De postcode + huisnummer combinatie is niet gevonden.');
					$sendResponse['messageTarget'] = 'housenumber';
				break;
				case 'PostcodeNl_Controller_Address_InvalidHouseNumberException':
					$sendResponse['message'] = ('Het huisnummer is ongeldig. Vul hier geen toevoeging in.');
					$sendResponse['messageTarget'] = 'housenumber';
				break;
				default:
					$sendResponse['message'] = ('Het adres kon niet worden gevonden. Vul het adres handmatig in.');
					$sendResponse['messageTarget'] = 'housenumber';
				break;
			}
		}
		else if (is_array($response) && isset($response['postcode']))
		{
			$sendResponse = array_merge($sendResponse, $response);
		}
		else
		{
			$sendResponse['message'] = ('Het adres kon niet worden gevonden. Vul het adres handmatig in.');
			$sendResponse['messageTarget'] = 'housenumber';
		}
		//print_r(json_encode($sendResponse));
		print_r(json_encode($sendResponse['showcaseResponse']));
	}
	lookupAddress($_POST['post_code'], $_POST['home_no'],'');
}
api();
?>