<?php
	/**
		* Template Name: analyse Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage twenthestad
		* @since twenthestad
	*/
get_template_part('home_header'); ?>
<div class="main_content web_ana_conts">
	<div class="container">
		<h1>Gratis website analyse</h1>
	</div>
	<div class="ques">
		<div class="container">
			<div class="web_ana_cont">
				<div class="row">
					<div class="col col-xs-12 col-sm-6 col-ms-6 col-lg-6">
						<div class="ana_cont1">
							<div class="form_group">
								<?php $language = $_GET['lang']; ?>
								<?php 
									if($language == "en"){
								echo do_shortcode('[contact-form-7 id="500" title="analyse form_english"]');
							 }else{
								echo do_shortcode('[contact-form-7 id="448" title="analyse form"]');
								}
								?>
								<?php //echo do_shortcode('[contact-form-7 id="448" title="analyse form"]');?>
								<!--<input class="Myinput"type="text" name="sub" placeholder="Bedrijf*">
									<input class="Myinput"type="text" name="sub" placeholder="Naam*">
									<input class="Myinput"type="text" name="sub" placeholder="Email*">
									<input class="Myinput"type="text" name="sub" placeholder="Telefoon*">
									<input class="Myinput"type="text" name="sub" placeholder="Website*">
								<button type="button" class="buts">ontvang een gratis analyse</button>-->
							</div>
							<?php if($language == "en"){ ?>
							<p>* You will receive your analysis within 72 hours</p>
							<?}else{ ?>
							<p>* U ontvangt uw analyse binnen 72 uur</p>
							<?php }?>
						</div>
					</div>
					<div class="col col-xs-12 col-sm-6 col-ms-6 col-lg-6">
						<div class="ana_cont2">
							<?php if ( ! dynamic_sidebar( 'sidebar-19' ) ) : ?>
							<?php
								the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
							?>
							<?php endif; // end sidebar widget area ?>
							<!--<h3>Wat wij onderzoeken:</h3>
								<ul class="list-block">
								<li><h6>Donec consectetur erat non sollicitudin.</h6></li>
								<li><h6>Nam orci est, volutpat ac neque eget.</h6></li>
								<li><h6>Sed quis urna pulvinar orci rhoncus ullamcorper nec eget erat.</h6></li>
								<li><h6>Pellentesque at elit tincidunt, malesuada ex sit amet, commodo quam.</h6></li>
							</ul>-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="<?php echo bloginfo('template_url');?>/js/formValidator/jquery.validate.js"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/jquery.validationEngine.js?v=1"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/languages/jquery.validationEngine-en.js?v=1"></script>
<script type="text/javascript">
	jQuery( document ).ready(function( $ ) {
		$(".wpcf7-form").validate({
			rules:{
				'bedrijf': {
					required: true
				},
				'your-name': {
					required: true
				},
				'your-email':{
					required: true,
					email: true
				},
				'phone':{
					required: true,
					number:true
				} ,
				'website':{
					required: true,
				} ,
			},
			messages: {
				'bedrijf': { required	 : <?php echo json_encode("bedrijf required.");?> },
				'your-name': { required	 : <?php echo json_encode("name required.");?> },
				'phone':{ required	 : <?php echo json_encode("phone number required.");?>,
				'number':<?php echo json_encode("must be a number");?> },
				'your-email': { required :<?php echo json_encode("mail required.");?> ,
					email	 :<?php echo json_encode("mail format is wrong");?>
				},
				'website': { required	 : <?php echo json_encode("website required");?> },
			},
		});
	});
</script>
<?php get_footer(); ?>