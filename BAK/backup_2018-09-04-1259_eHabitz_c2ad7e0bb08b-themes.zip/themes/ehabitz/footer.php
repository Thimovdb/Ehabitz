<footer>
	<div class="foot_newsletter" id="scrollAanmeldenCont">
		<div class="container">
			<h3>Ontvang gratis marketingtips per e-mail!</h3>
			<form class="form-group" id="subscribeForm" method="post" >
				<input class="Myinput"type="email" name="emailId" id="emailId" placeholder="Vul je e-mailadres in...">
				<input type="submit" class="buts" id="subscribeUsBtn" value="Gratis aanmelden" />
			</form>
			<h4 id="subscribeResponse"></h4>
		</div>
	</div>
	<div class="foot_list">
		<div class="container lists">
			<div class="list_1">
				<img src="<?php echo  get_template_directory_uri()?>/images/foot_logo.png">
				<?php if ( ! dynamic_sidebar( 'sidebar-3' ) ) : ?>
				<?php
					the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
				?>
				<?php endif; // end sidebar widget area ?>
			</div>
			<div class="list_2">
				<h4>informatie</h4>
				<ul class="list-block">
					<?php wp_nav_menu( array(
						'menu_class' => 'list-block',
						'theme_location' => 'bottom',
						'menu_id'        => 'bottom_menu',
					) ); ?>
					<!--<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Returns Exchange</a></li>
						<li><a href="#">Customer Services</a></li>
						<li><a href="#">Terms & Condition</a></li>
					<li><a href="#">Site Map</a></li>-->
				</ul>
			</div>
			<div class="list_3">
				<h4>Social media</h4>
				<div class="social">
					<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>
					<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
					?>
					<?php endif; // end sidebar widget area ?>
				</div>
			</div>
			<div class="list_4">
				<h4>Contact</h4>
				<?php if ( ! dynamic_sidebar( 'sidebar-2' ) ) : ?>
				<?php
					the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
				?>
				<?php endif; // end sidebar widget area ?>
			</div>
		</div>
		<div class="foot_copy">
			<?php if ( ! dynamic_sidebar( 'sidebar-4' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
		</div>
	</div>
	<div class="foot_popup">
		<div class="container">
			<div class="cokkie-text">
				<p>Deze website maakt gebruik van cookies. Door te klikken op “accepteren” gaat u akkoord met de <a href="<?php get_site_url();?>"  data-toggle="modal" data-target="#myModal">cookie policy.</a>
					<div class="modal fade" id="myModal" role="dialog">
						<div class="modal-dialog pop">
							<div class="modal-content">
								<div class="search_bar">
									<?php
										$language = $_GET['lang'];
										// the query
										if($language == "en"){
											$the_query = new WP_Query( array(
											'category_name' => 'cookie-2',
											));
											}else{
											$the_query = new WP_Query( array(
											'category_name' => 'cookie',
											));
										}
									?>
									<?php if ( $the_query->have_posts() ) :  ?>
									<?php while ( $the_query->have_posts() ) : $the_query->the_post();?>
									<?php the_title(); ?>
									<?php the_content(); ?>
									<?php endwhile; ?>
									<?php wp_reset_postdata(); ?>
									<?php else : ?>
									<p><?php __('No Posts'); ?></p>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</p>
			</div>
			<div class="popup_buttons">
				<button type="button" id="setCookieBtn" class="buts">Accepteren</button>
				<button type="button" class="buts1" id="cancelCookieBtn"></button>
			</div>
		</div>
	</div>
</footer>
</div>
<script src="<?php echo bloginfo('template_url');?>/js/formValidator/jquery.validate.js"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/jquery.validationEngine.js?v=1"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/languages/jquery.validationEngine-en.js?v=1"></script>
<script defer src="<?php echo bloginfo('template_url');?>/js/ehabitz.js"></script>
<script>
	$(document).ready(function() {
		if(document.getElementById("banner_slider") != null) {
			$("#banner_slider").owlCarousel({
				autoPlay: 2000,
				stopOnHover:true,
				singleItem:true,
				lazyLoad:true,
				loop:true,
				margin:10,
				pagination:true,
				navigation:false
			});
		}
	});
</script>
<script>
	if(document.getElementById("blog_slider") != null) {
		$("#blog_slider").owlCarousel({
			margin:10,
			stopOnHover:true,
			loop:true,
			items:4,
			autoPlay: 2000,
			stopOnHover:true,
			navigation:true,
			pagination:true,
			navigationText:["",""]
		});
	}
</script>
<script>
	if(document.getElementById("rate_slider") != null) {
		$("#rate_slider").owlCarousel({
			margin:10,
			stopOnHover:true,
			loop:true,
			items:3,
			autoPlay: 2000,
			stopOnHover:true,
			navigation:true,
			pagination:true,
			navigationText:["",""]
		});
	}
</script>
<script>
	$(function(){
		$("#opt1").on({
			mouseenter: function(){
				$("#opt1 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt1 img").removeClass('grayscale');
			}
		});
	});
	$(function(){
		$("#opt2").on({
			mouseenter: function(){
				$("#opt2 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt2 img").removeClass('grayscale');
			}
		});
	});
	$(function(){
		$("#opt3").on({
			mouseenter: function(){
				$("#opt3 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt3 img").removeClass('grayscale');
			}
		});
	});
	$(function(){
		$("#opt4").on({
			mouseenter: function(){
				$("#opt4 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt4 img").removeClass('grayscale');
			}
		});
	});
	$(function(){
		$("#opt5").on({
			mouseenter: function(){
				$("#opt5 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt5 img").removeClass('grayscale');
			}
		});
	});
	$(function(){
		$("#opt6").on({
			mouseenter: function(){
				$("#opt6 img").addClass('grayscale');
			},
			mouseleave: function(){
				$("#opt6 img").removeClass('grayscale');
			}
		});
	});
</script>
<script>
	$(function(){
		$("#serv1").on({
			mouseenter: function(){
				$("#serv1 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv1-hover.png');
			},
			mouseleave: function(){
				$("#serv1 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv1.png');
			}
		});
	});
	$(function(){
		$("#serv2").on({
			mouseenter: function(){
				$("#serv2 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv2-hover.png');
			},
			mouseleave: function(){
				$("#serv2 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv2.png');
			}
		});
	});
	$(function(){
		$("#serv3").on({
			mouseenter: function(){
				$("#serv3 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv3-hover.png');
			},
			mouseleave: function(){
				$("#serv3 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv3.png');
			}
		});
	});
	$(function(){
		$("#serv4").on({
			mouseenter: function(){
				$("#serv4 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv4-hover.png');
			},
			mouseleave: function(){
				$("#serv4 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv4.png');
			}
		});
	});
	$(function(){
		$("#serv5").on({
			mouseenter: function(){
				$("#serv5 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv5-hover.png');
			},
			mouseleave: function(){
				$("#serv5 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv5.png');
			}
		});
	});
	$(function(){
		$("#serv6").on({
			mouseenter: function(){
				$("#serv6 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv6-hover.png');
			},
			mouseleave: function(){
				$("#serv6 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv6.png');
			}
		});
	});
	$(function(){
		$("#serv7").on({
			mouseenter: function(){
				$("#serv7 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv7-hover.png');
			},
			mouseleave: function(){
				$("#serv7 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv7.png');
			}
		});
	});
	$(function(){
		$("#serv8").on({
			mouseenter: function(){
				$("#serv8 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv8-hover.png');
			},
			mouseleave: function(){
				$("#serv8 img").attr('src','<?php echo  get_template_directory_uri()?>/images/serv8.png');
			}
		});
	});
	$(document).ready(function(){
		$(".OpenNav").click(function(){
			$(".menu ul").fadeToggle();
			$(".menu").fadeIn();
			$(".CloseNav").show();
		});
		$(".CloseNav").click(function(){
			$(".menu ul").fadeToggle();
			$(".OpenNav").show();
			$(".CloseNav").hide();
		});
	});
</script>
</body>
</html>