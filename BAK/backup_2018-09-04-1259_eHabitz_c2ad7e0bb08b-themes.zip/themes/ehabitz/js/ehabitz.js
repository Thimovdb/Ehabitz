$(".foot_popup").css('display','none');
$(document).ready(function() {
	// $("#searchLink").click(function(){
	// alert();
	// $("#searchTextBox").focus();
	// });
	$.ajax({
		url: ajaxurl,
		type:   'post',
		cache:  'false',
		data: { 'action' : 'checkCookieData' },
		success: function(data) {
			var response = JSON.parse(data);
			//console.log(response);
			if(response.status=="success"){
				$(".foot_popup").css('display','block');
			}
			else{
				return true;
			}
		},
		error: function() {
			console.error('fail');
		}
	});
	// if ($.cookie('site_ip')) {
	// $(".foot_popup").css('display','none');
	// }
	// else{
	// $(".foot_popup").css('display','block');
	// }
	
	var url = $(location).attr('href'),
	parts = url.split("/"),
	last_part = parts[parts.length-2];
	// alert(last_part);
	if(last_part == "diensten"){
		$("#breadCrumb").html("Home / Diensten");
	}
	else if(last_part == "team"){
		$("#breadCrumb").html("Home / Team");
	}
	else if(last_part == "faq"){
		$("#breadCrumb").html("Home / FAQ");
	}
	else if(last_part == "blog"){
		$("#breadCrumb").html("Home / Blog");
	}
	else if(last_part == "contact"){
		$("#breadCrumb").html("Home / Contact");
	}
	else if(last_part == "analyse"){
		$("#breadCrumb").html("Home / Website analyse");
	}
	
	else if(last_part == "ehabitz"){
		$("#breadCrumb").html("Home / Search");
	}
	else if(last_part == "overons"){
		$("#breadCrumb").html("Home / Over ons");
	}
	else if(last_part == "privacy-policy"){
		$("#breadCrumb").html("Home / Privacy policy");
	}
	else if(last_part == "sitemap"){
		$("#breadCrumb").html("Home / Site Map");
	}
	else if(last_part == "return-exchange"){
		$("#breadCrumb").html("Home / Returns Exchange");
	}
	else if(last_part == "terms-and-conditions"){
		$("#breadCrumb").html("Home / Terms & Conditions");
	}
	else{
		$("#breadCrumb").html("Home / Details");
	}
	
	$("#cancelCookieBtn").click(function(){
		$(".foot_popup").css('display','none');
	});
	$("#setCookieBtn").click(function(){
		// alert();
		$.ajax({
			url: ajaxurl,
			type:   'post',
			cache:  'false',
			data: { 'action' : 'setCookieData' },
			success: function(data) {
				console.debug(data);
				$(".foot_popup").css('display','none');
			},
			error: function() {
				console.error('fail');
			}
		});
	});
	$("#subscribeForm").validate({
		rules:{
			emailId:{
				required: true,
				email: true
			},
		},
		messages: {
			emailId: { required :"Vul een e-mailadres in." ,
				email	 :"Vul een correct e-mailadres in.",
			},
		},
		submitHandler:function(form){
			$email = $("#emailId").val();
			$.ajax({
				url: ajaxurl,
				type:   'post',
				cache:  'false',
				data: { 'action' : 'subscribe', 'email' : $email },
				success: function(data) {
					// console.debug(data);
					var response = JSON.parse(data);
					console.log(response);
					if(response.status=="success"){
						console.log("success");
						$("#subscribeResponse").html("subscription success");
					}
					else{
						console.log("failed");
						$("#subscribeResponse").html("failed to subscribe");
					}
				},
				error: function() {
					console.error('fail');
					$("#subscribeResponse").html("failed to subscribe");
				}
			});
		}
	});
	$("#scrollAanmelden, #scrollAanvraag").click(function() {
		$('html, body').animate({
			scrollTop: $("#scrollAanmeldenCont").offset().top-50
		}, 1000);
	});
	// $(".buts").click(function(){
		// $(this).parents("div.ques_conts").toggleClass("active");
	// });
	// $(".buts").on("click", function(){
		// $(this).parents("div.ques_conts").toggleClass("active");
	// });
	// $(".ques_conts h4").click(function(){
		// $(this).next().trigger("click");
	// });
	// $('.ques_conts').on('click',function() {
		// $(this).next().trigger("click");
	// });
	// $(document).on('click', ".buts" , function() {
		// $(this).parents("div.ques_conts").toggleClass("active");
	// });
	$(document).on('click', ".ques_conts h4" , function() {
		$(this).next().trigger("click");
	});
	
	// var path = window.location.pathname.split("\/"), myString;

// if(path[path.length-1] === "")
    // myString = path[path.length-2];

// else
   // myString = path[path.length-1];

// myString = myString.toLowerCase()
// console.log(myString);
		
		// console.log($('.wpml-ls-current-language a').children()[0]);
		// console.log($('.wpml-ls-current-language a').children()[1]);
		$("#languageDropDown").html($('.wpml-ls-current-language a').children()[0]);
		$("#languageDropDown").append(' ');
		$("#languageDropDown").append($('.wpml-ls-current-language a').children()[0]);
		   

	/* $(function () {
		var url = window.location.pathname,
		urlRegExp = new RegExp(url.replace(/\/$/, '') + "$");
		$('a').each(function () {
			if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
				$(this).addClass('active');
			}
		});
	}); */
	$(".serv_group").click(function(){
		window.location.href = "http://ehabitzmarketing.nl/dienstein/";
	});
	$(".opt_group").click(function(){
		var linkID = $("#hiddenOptimizationID").val();
		window.location.href = "http://ehabitzmarketing.nl/optimalize/?id="+linkID;
	});
	$("#languageDropDown").click(function(){
		$("#translator").toggleClass("activeLanguage");
	});

});