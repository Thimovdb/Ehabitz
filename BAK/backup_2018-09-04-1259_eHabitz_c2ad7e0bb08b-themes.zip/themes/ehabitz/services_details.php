<?php
	/**
		* Template Name: service_detail Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); ?>
<div class="main_content service_details_page_conts">
	<div class="container">
		<div class="service_details_page_cont1">
			<div class="row">
				<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
					<div class="tab_buttons">
						<?php $idFromUrl = $_GET['id'];?>
						
						
						<?php
							
							$language = $_GET['lang'];
							// the query
							if($language == "en"){
								$the_query = new WP_Query( array('category_name' => 'diensten-2','order' => 'asc'));
								}else{
								$the_query = new WP_Query( array('category_name' => 'diensten','order' => 'asc'));
							}
						//$the_query = new WP_Query( array('category_name' => 'diensten','order' => 'asc')); ?>
						<?php if ( $the_query->have_posts() ) : $count = 0; $count_1=10; ?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++; $count_1++;?>
						<!--<input type="text" value="<?php echo get_the_ID() ?>"/>-->
						<button type="button" class="buts tablinks but_<?php echo $count; ?>" onclick="openServData(event, 'serv_data_tab<?php echo $count; ?>','serv_data_tab<?php echo $count_1;?>')" id="butn_<?php echo get_the_ID() ?>"><?php the_title(); ?></button>
						
						<!--id="<?php if(!empty($idFromUrl)&&$idFromUrl == get_the_ID()){ ?>defaultOpen<?php } ?>"-->
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						<!--<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab1','serv_data_tab11')" id="defaultOpen">Code optimlisatie</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab2','serv_data_tab12')" >Zoekmachine optimisatie</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab3','serv_data_tab13')" >SEA / advertenties</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab4','serv_data_tab14')" >Marketing monitoring</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab5','serv_data_tab15')" >Target strategies</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab6','serv_data_tab16')" >Conversie optimisatie</button>
							<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab7','serv_data_tab17')" >Social media marketing</button>
						<button type="button" class="buts tablinks" onclick="openServData(event, 'serv_data_tab8','serv_data_tab18')" >Email marketing</button>-->
					</div>
				</div>
				<div class="col col-xs-12 col-sm-9 col-md-9 col-lg-9">
					<div class="tab_contents">
						<div id="serv_data_tab1" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img1.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab2" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img2.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab3" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img3.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab4" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img1.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab5" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img3.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab6" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img4.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab7" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img2.png" alt="tab_imges">
						</div>
						<div id="serv_data_tab8" class="tab_content">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_tab_img1.png" alt="tab_imges">
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="service_details_page_cont2">
			<?php if($language == "en"){
				$the_query = new WP_Query( array('category_name' => 'diensten-2','order' => 'asc'));
				}else{
				$the_query = new WP_Query( array('category_name' => 'diensten','order' => 'asc'));
			}
			//$the_query = new WP_Query( array('category_name' => 'diensten','order' => 'asc')); ?>
			<?php if ( $the_query->have_posts() ) : $count = 0; ?>
			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++; ?>
			<div id="serv_data_tab1<?php echo $count; ?>" class="tab_content" class="service_details_page_cont2_text">
				<h1><?php the_title(); ?></h1>
				<p><?php the_content(); ?></p>
				<?php //the_post_thumbnail();?>
				<?php
					$thumb = $dynamic_featured_image->get_featured_images(get_the_ID());
					foreach($thumb as $th){
					?>
					
					<a href="<?php echo $th['full'];?>" data-lightbox="example-1"><img src="<?php echo $th['full'];?>"/></a>
					
				<?php } ?>
				
				
			</div>
			
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
			<?php else : ?>
			<p><?php __('No Posts'); ?></p>
			<?php endif; ?>
			
			<!--<div class="service_details_page_cont2_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img1.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img2.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img3.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img4.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img5.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img6.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img7.png" alt="serv_data_images">
				<img src="<?php echo  get_template_directory_uri()?>/images/serv_data_img8.png" alt="serv_data_images">
			</div>-->
		</div>
	</div>
</div>
<script>
	function openServData(evt, tabName,tabName2) {
		var i, tab_content, tablinks;
		tab_content = document.getElementsByClassName("tab_content");
		for (i = 0; i < tab_content.length; i++) {
			tab_content[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("tablinks");
		for (i = 0; i < tablinks.length; i++) {
			tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(tabName).style.display = "inline-block";
		document.getElementById(tabName2).style.display = "block";
		evt.currentTarget.className += " active";
		var crntTab = $("button.active").html();
		
		$("#breadCrumb").html("Home / Details / "+crntTab);
		
	}
	// Get the element with id="defaultOpen" and click on it
	//document.getElementById("defaultOpen").click();
</script>
<?php if(empty($idFromUrl)){ ?>
	<script>
		$(".but_1").trigger("click");
	</script>
	<?php }
	else{?>
	<script>
		var id = "butn_<?php echo $idFromUrl;?>";
		//alert(id);
		document.getElementById(id).click();
		var crntTab = $("button.active").html();
	</script>
	<?php }
?>
<?php get_footer(); ?>