<?php
	/**
		* Template Name: team Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); 
$language = $_GET['lang'];
?>

<?php
	//$all_meta_for_user = get_user_meta( 1 );
	// echo"<pre>"; print_r( $all_meta_for_user );echo"</pre>";
?>
<div class="main_content team_page_conts">
	<div class="container">
		<h1>Team</h1>
		<div class="our_teams">
			<div class="row">
				<?php //$the_query = new WP_Query( 'category_name=team&order=asc' );?>
				<?php 
					
				if($language == 'en'){
								//$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=1' );
								$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'team-2','post_type' => 'post','posts_per_page' => 2));
							}
							else{
								//$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=1' );
								$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'team','post_type' => 'post','posts_per_page' => 2));
							}
				?>
					<?php if ( $the_query->have_posts() ) : ?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					<div class="col-xs-12 col-sm-3 col-md-3 col-lg3 col">
					<div class="member_group">
						<div class="member_img">
							<?php the_post_thumbnail(); ?>
						</div>
						<div class="member_text">
							<h2><?php the_title(); ?></br><span><?php echo do_shortcode('[jcf-value field="_role"]'); ?></span></h2>
							<p><?php the_content();?> </p>
							<div class="social_media">
								<ul class="list-inline">
									<li><a href="https://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="Share on Facebook."><div class="facebook"></div></a></li>
									<!--<li><a href="#"><div class="instagram"></div></a></li>-->
									<li><a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" title="Tweet this!"><div class="twitter"></div></a></li>
									<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>"><div class="pin"></div></a></li>
									<li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
							'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><div class="google"></div></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
				<div class="posts"></div>
				
			</div>
		</div>
		<button id="loadMore" class="buts">MEER LADEN</button>
	</div>
</div>
<?php $category = get_category(12);
	$blog_count = $category->category_count; ?>	
<Script type="text/javascript">
	
	
	var count = 2;
	var total_post = "<?php echo $blog_count; ?>";
	
	var total_page = total_post/2;
	var intvalue = Math.round(total_page);
	
	$("#loadMore").click(function(){
		
			if(count > intvalue)
			{
				$(".loading").css('display','none');
			}
			else
			{
				fetch(count);
				count++;
			}
	});
	
	function fetch(pageNumber)
	{
		var data = {'action' : 'load_team','page' : pageNumber};
		$.post(ajaxurl, data, function(response){
			$('.posts').append(response);
		});
	}
</script>
<?php get_footer(); ?>