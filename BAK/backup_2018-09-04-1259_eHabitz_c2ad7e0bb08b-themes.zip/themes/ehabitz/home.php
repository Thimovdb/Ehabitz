<?php
	/**
		* Template Name: home Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
	get_header();
	$language = $_GET['lang'];
?>
<div class="main_contant">
	<div class="specialties">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-6' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>seo and sea</h3>
				<h1>Onze specialiteiten</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div class="spa_conts">
				<div class="row">
					<?php if ( ! dynamic_sidebar( 'sidebar-7' ) ) : ?>
					<?php
						the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
					?>
					<?php endif; // end sidebar widget area ?>
					<!--<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont1">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa1.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont2">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa2.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont3">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa3.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont4">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa4.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont5">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa5.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div class="spa_cont6">
						<img src="<?php echo  get_template_directory_uri()?>/images/spa6.png" alt="spa1">
						<h4>Data en zoekwoorden analyse</h4>
						<p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there.</p>
						</div>
					</div>-->
				</div>
			</div>
		</div>
	</div>
	<div class="over_ons">
		<div class="container1">
			<div class="row">
				<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<div class="over_ons_cont1">
						<?php if ( ! dynamic_sidebar( 'sidebar-18' ) ) : ?>
						<?php
							the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php endif; // end sidebar widget area ?>
						<!--<h3>Werk samen met eHabitz</h3>
							<h1>GROEI SAMEN MET Ehabitz</h1>
							<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>
							<p>Proin accumsan lectus hendrerit sapien tincidunt, sed hendrerit risus ultrices. Vestibulum sed porta sem. Quisque non convallis neque. Nulla fringilla ultrices neque id suscipit. </p>
						<button type="button" class="buts">Lees Meer</button>-->
						<a href="<?php echo get_site_url()?>/overons" class="buts">Lees Meer</a>
					</div>
				</div>
				<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<div class="over_ons_cont2">
						<img src="<?php echo  get_template_directory_uri()?>/images/overonsimg.png" alt="about_img">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="service">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-8' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Verwacht meer</h3>
				<h1>onze diensten</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div class="service_conts">
				<div class="row text-center">
					<?php
						// the query
						//$the_query = new WP_Query( 'showposts=4&category_name=diensten&order=asc' );
						if($language == 'en'){
							$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten-2','showposts' => 4));
						}
						else{
							$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten','showposts' => 4));
						}
					?>
					<?php if ( $the_query->have_posts() ) : $count=0;?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
					<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
						<div id="serv<?php echo $count;?>" class="serv_group">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv<?php echo $count;?>.png" alt="Serv">
							<!--<?php the_post_thumbnail(); ?>-->
							<h4><?php the_title(); ?></h4>
							<!--<p><?php the_content();?></p>-->
							<span class="serv_cont"><?php the_excerpt(); ?></span>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
				</div>
				<div class="row">
					<?php
						// the query
						//$the_query = new WP_Query( 'showposts=4&category_name=diensten&order=asc&offset=4' );
						if($language == 'en'){
							$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten-2','showposts' => 4, 'offset'=>4));
						}
						else{
							$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten','showposts' => 4, 'offset'=>4));
						}
					?>
					<?php if ( $the_query->have_posts() ) : $count=4;?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
					<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
						<div id="serv<?php echo $count;?>" class="serv_group">
							<img src="<?php echo  get_template_directory_uri()?>/images/serv<?php echo $count;?>.png" alt="Serv">
							<!--<?php the_post_thumbnail(); ?>-->
							<h4><?php the_title(); ?></h4>
							<!--<p><?php the_content();?></p>-->
							<span class="serv_cont"><?php the_excerpt(); ?></span>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
				</div>
			</div>
			<!--<button type="button" class="buts">Al onze diensten</button>-->
			<a href="<?php echo get_site_url()?>/service-detail/" class="buts">Al onze diensten</a>
		</div>
	</div>
	<div class="request">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-14' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h1>Offerte aanvraag</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<button class="buts" id="scrollAanvraag" type="button">Gratis aanvraag</button>
			<!--<a href="#" class="buts">Gratis aanvraag</a>-->
		</div>
	</div>
	<div class="customers">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-9' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Met trots</h3>
				<h1>Onze klanten</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div class="cus_img">
				<?php
					// the query
					//$the_query = new WP_Query( 'category_name=gallery' );
					if($language == 'en'){
						$the_query = $the_query = new WP_Query( array('category_name' => 'gallery-2'));
					}
					else{
						$the_query = $the_query = new WP_Query( array('category_name' => 'gallery'));
					}
				?>
				<?php if ( $the_query->have_posts() ) :?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				<?php remove_filter ('the_content', 'wpautop'); the_content(); ?>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php else : ?>
				<p><?php __('No Posts'); ?></p>
				<?php endif; ?>
				<!--<img src="<?php echo  get_template_directory_uri()?>/images/avast.png" alt="avast">
					<img src="<?php echo  get_template_directory_uri()?>/images/bridgestore.png" alt="bridgestor">
					<img src="<?php echo  get_template_directory_uri()?>/images/bugingshow.png" alt="bugingshow">
					<img src="<?php echo  get_template_directory_uri()?>/images/caratlane.png" alt="caratlane">
					<img src="<?php echo  get_template_directory_uri()?>/images/celexon.png" alt="celexon">
					<img src="<?php echo  get_template_directory_uri()?>/images/cisco.png" alt="cisco">
					<img src="<?php echo  get_template_directory_uri()?>/images/copart.png" alt="copart">
					<img src="<?php echo  get_template_directory_uri()?>/images/forest.png" alt="forest">
					<img src="<?php echo  get_template_directory_uri()?>/images/grabyo.png" alt="grabyo">
					<img src="<?php echo  get_template_directory_uri()?>/images/honda.png" alt="honda">
					<img src="<?php echo  get_template_directory_uri()?>/images/lenscart.png" alt="lenscart">
					<img src="<?php echo  get_template_directory_uri()?>/images/moneycorp.png" alt="moneycorp">
					<img src="<?php echo  get_template_directory_uri()?>/images/quizup.png" alt="quizup">
					<img src="<?php echo  get_template_directory_uri()?>/images/teamviewer.png" alt="teamviewer">
					<img src="<?php echo  get_template_directory_uri()?>/images/toshiba.png" alt="toshiba">
					<img src="<?php echo  get_template_directory_uri()?>/images/unicef.png" alt="unicef">
					<img src="<?php echo  get_template_directory_uri()?>/images/penn.png" alt="penn">
				<img src="<?php echo  get_template_directory_uri()?>/images/zomato.png" alt="zomato">-->
			</div>
		</div>
	</div>
	<div class="our_blog">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-10' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Updates via</h3>
				<h1>Ons blog</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div id="blog_slider" class="owl-carousel owl-theme">
				<?php
					// the query
					if($language == 'en'){
						//$the_query = $the_query = new WP_Query( array('category_name' => 'gallery-2'));
						$the_query = new WP_Query( 'showposts=3&category_name=optimization-2&order=asc' );
						$the_query = new WP_Query( array(
						'category_name' => 'blog-2',
						'order' => 'ASC'
						));
					}
					else{
						$the_query = new WP_Query( 'showposts=3&category_name=optimization&order=asc');
						$the_query = new WP_Query( array(
						'category_name' => 'blog',
						'order' => 'ASC'
						));
					}
				?>
				<?php if ( $the_query->have_posts() ) : ?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				<div class="item">
					<div class="blog">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
						<h6><?php the_time('j M'); ?></h6>
						<div class="blog_cont">
							<!--<h4><?php remove_filter ('the_content', 'wpautop'); the_content(); ?></h4>-->
							<h4><?php echo(get_the_excerpt()); ?></h4>
							<a href="<?php the_permalink(); ?>">Lees meer</a>
						</div>
					</div>
				</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php else : ?>
				<p><?php __('No Posts'); ?></p>
				<?php endif; ?>
				<!--<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog1.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog2.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog3.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog4.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog1.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog2.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog3.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog4.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog1.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog2.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog3.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
					</div>
					<div class="item">
					<div class="blog">
					<img src="<?php echo  get_template_directory_uri()?>/images/blog4.png" alt="blogs">
					<h6>11 mar</h6>
					<h4>Nullam ligula massa, faucibus eget...</h4>
					<a href="#">Lees meer</a>
					</div>
				</div>-->
			</div>
		</div>
	</div>
	<div class="result_optimize">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-11' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Bewijs dat het werkt</h3>
				<h1>Resultaat gerichte optimalisaties</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div class="opt_groups">
				<div class="row">
					<?php
						// the query
						//$the_query = new WP_Query( 'showposts=3&category_name=optimization&order=asc&offset=3' );
						if($language == 'en'){
							//$the_query = $the_query = new WP_Query( array('category_name' => 'gallery-2'));
							$the_query = new WP_Query( 'showposts=3&category_name=optimization-2&order=asc' );
						}
						else{
							$the_query = new WP_Query( 'showposts=3&category_name=optimization&order=asc');
						}
					?>
					<?php if ( $the_query->have_posts() ) : $count = 0;?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div id="opt<?php echo $count;?>" class="opt_group">
							<?php// the_post_thumbnail(); ?>
							<img src="<?php echo  get_template_directory_uri()?>/images/opt<?php echo $count;?>-hover.png" alt="opt">
							<div class="opt_conts">
								<input type="hidden" id="hiddenOptimizationLink" value="<?php echo the_permalink(); ?>" />
								<h4><?php the_title(); ?></h4>
								<ul class="list-block">
									<?php the_content();?>
								</ul>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
				</div>
				<div class="row group2">
					<?php
						// the query
						//$the_query = new WP_Query( 'showposts=3&category_name=optimization&order=asc&offset=3' );
						if($language == 'en'){
							$the_query = new WP_Query( 'showposts=3&category_name=optimization-2&order=asc&offset=3' );
						}
						else{
							$the_query = new WP_Query( 'showposts=3&category_name=optimization&order=asc&offset=3' );
						}
					?>
					<?php if ( $the_query->have_posts() ) : $count = 3;?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<div id="opt<?php echo $count;?>" class="opt_group">
							<?php// the_post_thumbnail(); ?>
							<img src="<?php echo  get_template_directory_uri()?>/images/opt<?php echo $count;?>-hover.png" alt="opt">
							<div class="opt_conts">
								<input type="hidden" id="hiddenOptimizationLink" value="<?php echo the_permalink(); ?>" />
								<input type="hidden" id="hiddenOptimizationID" value="<?php echo get_the_ID(); ?>" />
								<h4><?php the_title(); ?></h4>
								<ul class="list-block">
									<?php the_content();?>
								</ul>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
				</div>
				<!--<div class="row">
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt1" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt1.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt2" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt2.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt3" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt3.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
					</div>
					<div class="row group2">
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt4" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt4.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt5" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt5.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div id="opt6" class="opt_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/opt6.png" alt="opt">
					<div class="opt_conts">
					<h4>Pagina optimalisatie</h4>
					<ul class="list-block">
					<li>Interne linkstructuur</li>
					<li>HTML Code Cleanup</li>
					<li>Teksten</li>
					<li>Inhoudsoptimalisatie</li>
					</ul>
					</div>
					</div>
					</div>
				</div>-->
			</div>
		</div>
	</div>
	<div class="customer_rating">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-13' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Happy klanten</h3>
				<h1>Klantbeoordelingen</h1>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>-->
			<div id="rate_slider" class="owl-carousel owl-theme">
				<?php
					// the query
					if($language == "en"){
						$the_query = new WP_Query( array(
						'category_name' => 'ratings-2',
						'order' => 'ASC'
						));
						}else{
						$the_query = new WP_Query( array(
						'category_name' => 'ratings',
						'order' => 'ASC'
						));
					}
					// the query
					$the_query = new WP_Query( array(
					'category_name' => 'ratings',
					// 'posts_per_page' => 9,
					// 'order' => 'ASC'
					));
				?>
				<?php if ( $the_query->have_posts() ) : ?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				<div class="item">
					<div class="rate_group">
						<?php the_post_thumbnail(); ?>
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/user2.png" alt="user">-->
						<h5>02</h5>
						<div class="rate_group_cont">
							<h4><?php the_title();?></h4>
							<h6><?php the_time('d-m-Y'); ?></h6>
						</div>
						<p><?php the_content();?></p>
					</div>
				</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php else : ?>
				<p><?php __('No Posts'); ?></p>
				<?php endif; ?>
				<!--<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user1.png" alt="user">
					<h5>01</h5>
					<h4>Peter de Vries</h4>
					<h6>12-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user2.png" alt="user">
					<h5>02</h5>
					<h4>Raymond van Dam</h4>
					<h6>13-03-2018</h6>
					<p>Pellentesque risus lorem, commodo sit amet lacinia sit amet, semper vitae lacus. Duis condimentum mi sit amet mauris.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user3.png" alt="user">
					<h5>03</h5>
					<h4>Stefan Beek</h4>
					<h6>14-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user1.png" alt="user">
					<h5>01</h5>
					<h4>Peter de Vries</h4>
					<h6>12-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user2.png" alt="user">
					<h5>02</h5>
					<h4>Raymond van Dam</h4>
					<h6>13-03-2018</h6>
					<p>Pellentesque risus lorem, commodo sit amet lacinia sit amet, semper vitae lacus. Duis condimentum mi sit amet mauris.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user3.png" alt="user">
					<h5>03</h5>
					<h4>Stefan Beek</h4>
					<h6>14-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user1.png" alt="user">
					<h5>01</h5>
					<h4>Peter de Vries</h4>
					<h6>12-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user2.png" alt="user">
					<h5>02</h5>
					<h4>Raymond van Dam</h4>
					<h6>13-03-2018</h6>
					<p>Pellentesque risus lorem, commodo sit amet lacinia sit amet, semper vitae lacus. Duis condimentum mi sit amet mauris.</p>
					</div>
					</div>
					<div class="item">
					<div class="rate_group">
					<img src="<?php echo  get_template_directory_uri()?>/images/user3.png" alt="user">
					<h5>03</h5>
					<h4>Stefan Beek</h4>
					<h6>14-03-2018</h6>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in sollicitudin erat. Proin eu ante finibus, pharetra nisi quis.</p>
					</div>
				</div>-->
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>