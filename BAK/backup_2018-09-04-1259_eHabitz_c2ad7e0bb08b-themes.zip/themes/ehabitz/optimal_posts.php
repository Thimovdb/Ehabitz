<?php
	/**
		* Template Name: optimalisatie Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); ?>
<?php 
	$id = $_GET['id'];
$queried_post = get_post($id);

$args = array(
  'p'         => $id, // ID of a page, post, or custom type
  'post_type' => 'any'
);
$the_query = new WP_Query($args);

?>
<div class="main_content opt_groups new-opt">
	<div class="container">
		<div class="row group2">
			<div class="col col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div id="opt4" class="opt_group">
					<?php if ( $the_query->have_posts() ) :?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					<?php the_post_thumbnail(); ?>
					<div class="opt_conts">
						<h4><?php echo the_title(); ?></h4>
						<ul class="list-block">
							<?php echo the_content(); ?>
						</ul>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php else : ?>
					<p><?php __('No Posts'); ?></p>
					<?php endif; ?>
					
					<!--<img src="<?php echo  get_template_directory_uri()?>/images/opt4.png" alt="opt">
					<?php get_the_post_thumbnail_url(); ?>
					<div class="opt_conts">
						<h4><?php echo $queried_post->post_title; ?></h4>
						<ul class="list-block">
							<?php echo $queried_post->post_content; ?>
						</ul>
					</div>-->
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>