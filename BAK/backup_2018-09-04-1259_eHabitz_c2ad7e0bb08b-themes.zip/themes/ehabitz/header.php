<!DOCTYPE html>
<html lang="nl">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>EHabitz</title>
		<link href="<?php echo bloginfo('template_url');?>/css/owl.theme.css" rel="stylesheet" />
		<link href="<?php echo bloginfo('template_url');?>/css/owl.transitions.css" type="text/css" rel="stylesheet"/>
		<link href="<?php echo bloginfo('template_url');?>/css/owl.carousel.css" type="text/css" rel="stylesheet" />
		<link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/css/bootstrap-theme.min.css" type="type/css" />
		
		<!--<script src="<?php echo bloginfo('template_url');?>/js/jquery-1.11.3.min.js"></script>-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="<?php echo bloginfo('template_url');?>/js/owl.carousel.js"></script>
		<script src="<?php echo bloginfo('template_url');?>/js/bootstrap.min.js"></script>
		<script src="<?php echo bloginfo('template_url');?>/js/jquery.cookie.js"></script>
		<script type="text/javascript">
			var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
		</script>
		<link href="<?php echo bloginfo('template_url');?>/css/style.css" rel="stylesheet" />
		<link href="<?php echo bloginfo('template_url');?>/css/responce.css" rel="stylesheet" />
		<link rel="shortcut icon" href="<?php bloginfo('template_url');?>/images/favicon.ico" type="image/x-icon">
	</head>
	<body>
		<div class="full_content">
			<header>
				<div class="top_panel">
					<div class="container">
						<?php if ( ! dynamic_sidebar( 'sidebar-5' ) ) : ?>
						<?php
							the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php endif; // end sidebar widget area ?>
						<div class="langugeContainer" id="languageContainer">
						<span id="languageDropDown">Languages</span>
						<div id="translator" class="translate">
							<?php if ( ! dynamic_sidebar( 'sidebar-20' ) ) : ?>
							<?php
								the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
							?>
							<?php endif; // end sidebar widget area ?>
							<?php //echo do_shortcode('[gtranslate]'); ?>
						</div>
						</div>
						<!--<p>info@ehabitz.nl</p>
							<p>085 130 0510</p>
						<h6>Ma / Vr 09:00 - 17:00 uur</h6>-->
					</div>
					
				</div>
				<div class="head_panel">
					<div class="head_menu">
						<div class="container">
							<div class="logo">
								<a href="<?php echo get_site_url();?>"><img src="<?php echo  get_template_directory_uri()?>/images/logo.png"></a>
							</div>
							<div class="icons">
								<div class="menu_open">
									<button class="OpenNav">&#9776;</button>
								</div>
								<div class="menu_close">
									<button class="CloseNav">&times;</button>
								</div>
							</div>
							<div class="menu">
								<!--<div class="togglr_icon"></div>-->
								<?php wp_nav_menu( array(
									'menu_class' => 'list-inline',
									'theme_location' => 'primary',
									'menu_id'        => 'top-menu',
								) ); ?>
							
							</div>
							<div class="search">
								<a id="searchLink" href="<?php get_site_url();?>"  data-toggle="modal" data-target="#myModalSearch"><div class="searchicon"></div></a>
								<div class="modal fade" id="myModalSearch" role="dialog">
									<div class="modal-dialog pop">
										<!-- Modal content-->
										<div class="modal-content">
											<div class="search_bar">
												<?php get_search_form(); ?>
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					<div class="head_cont">
						<div class="container1">
							<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
								<!-- Indicators -->
								<ol class="carousel-indicators carousel-indicators-numbers">
									<li data-target="#carousel-example-generic" data-slide-to="0"><div class="pad">03</div></li>
									<li data-target="#carousel-example-generic" data-slide-to="1"><div class="pad">02</div></li>
									<li data-target="#carousel-example-generic" data-slide-to="2" class="active"><div class="pad">01</div></li>
								</ol>
								<!-- Wrapper for slides -->
								<div class="carousel-inner" role="listbox">
								
									<?php
										$language = $_GET['lang'];
										// the query
										if($language == "en"){
											$the_query = new WP_Query( array(
											'category_name' => 'slider-2',
											'posts_per_page' => 3,
											'order' => 'ASC'
											));
										}else{
											$the_query = new WP_Query( array(
											'category_name' => 'slider',
											'posts_per_page' => 3,
											'order' => 'ASC'
											));
										}
									?>
									<?php if ( $the_query->have_posts() ) : $count = 0; ?>
									<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++; ?>
									<div class="item <?php if($count == 1){ ?>active<?php } ?>">
										<div class="slider_conts">
											<div class="slider_img">
												<img src="<?php echo  get_template_directory_uri()?>/images/laptop_ban.png">
												<?php //the_post_thumbnail(); ?>
											</div>
											<div class="slider_cont">
												<?php the_title(); ?>
												<?php the_content(); ?>
												<!--<button type="button" id="scrollAanmelden" class="buts">Aanmelden</button>-->
												<a href="<?php echo get_site_url()?>/service-detail" class="buts">Aanmelden</a>
											</div>
										</div>
									</div>
									<?php endwhile; ?>
									<?php wp_reset_postdata(); ?>
									<?php else : ?>
									<p><?php __('No Posts'); ?></p>
									<?php endif; ?>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>			