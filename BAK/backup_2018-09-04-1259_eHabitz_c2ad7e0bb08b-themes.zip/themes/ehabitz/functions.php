<?php
	/**
		* Twenty Fourteen functions and definitions
		*
		* Set up the theme and provides some helper functions, which are used in the
		* theme as custom template tags. Others are attached to action and filter
		* hooks in WordPress to change core functionality.
		*
		* When using a child theme you can override certain functions (those wrapped
		* in a function_exists() call) by defining them first in your child theme's
		* functions.php file. The child theme's functions.php file is included before
		* the parent theme's file, so the child theme functions would be used.
		*
		* @link https://codex.wordpress.org/Theme_Development
		* @link https://codex.wordpress.org/Child_Themes
		*
		* Functions that are not pluggable (not wrapped in function_exists()) are
		* instead attached to a filter or action hook.
		*
		* For more information on hooks, actions, and filters,
		* @link https://codex.wordpress.org/Plugin_API
		*
		* @package WordPress
		* @subpackage Twenty_Fourteen
		* @since Twenty Fourteen 1.0
	*/
	
	/**
		* Set up the content width value based on the theme's design.
		*
		* @see twentyfourteen_content_width()
		*
		* @since Twenty Fourteen 1.0
	*/
	if ( ! isset( $content_width ) ) {
		$content_width = 474;
	}
	
	/**
		* Twenty Fourteen only works in WordPress 3.6 or later.
	*/
	if ( version_compare( $GLOBALS['wp_version'], '3.6', '<' ) ) {
		require get_template_directory() . '/inc/back-compat.php';
	}
	
	if ( ! function_exists( 'twentyfourteen_setup' ) ) :
	/**
		* Twenty Fourteen setup.
		*
		* Set up theme defaults and registers support for various WordPress features.
		*
		* Note that this function is hooked into the after_setup_theme hook, which
		* runs before the init hook. The init hook is too late for some features, such
		* as indicating support post thumbnails.
		*
		* @since Twenty Fourteen 1.0
	*/
	
	
	function twentyfourteen_setup() {
		
		/*
			* Make Twenty Fourteen available for translation.
			*
			* Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentyfourteen
			* If you're building a theme based on Twenty Fourteen, use a find and
			* replace to change 'twentyfourteen' to the name of your theme in all
			* template files.
		*/
		load_theme_textdomain( 'twentyfourteen' );
		
		// This theme styles the visual editor to resemble the theme style.
		add_editor_style( array( 'css/editor-style.css', twentyfourteen_font_url(), 'genericons/genericons.css' ) );
		
		// Add RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );
		
		// Enable support for Post Thumbnails, and declare two sizes.
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 672, 372, true );
		add_image_size( 'twentyfourteen-full-width', 1038, 576, true );
		
		// This theme uses wp_nav_menu() in two locations.
		register_nav_menus( array(
		'primary'   => __( 'Top primary menu', 'twentyfourteen' ),
		'bottom' => __( 'Bottom menu', 'twentyfourteen' ),
		'social_media' => __( 'Social media menu', 'twentyfourteen' ),
		) );
		
		/*
			* Switch default core markup for search form, comment form, and comments
			* to output valid HTML5.
		*/
		add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
		) );
		
		/*
			* Enable support for Post Formats.
			* See https://codex.wordpress.org/Post_Formats
		*/
		add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'audio', 'quote', 'link', 'gallery',
		) );
		
		// This theme allows users to set a custom background.
		add_theme_support( 'custom-background', apply_filters( 'twentyfourteen_custom_background_args', array(
		'default-color' => 'f5f5f5',
		) ) );
		
		// Add support for featured content.
		add_theme_support( 'featured-content', array(
		'featured_content_filter' => 'twentyfourteen_get_featured_posts',
		'max_posts' => 6,
		) );
		
		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );
		
		// Indicate widget sidebars can use selective refresh in the Customizer.
		add_theme_support( 'customize-selective-refresh-widgets' );
		
	}
	endif; // twentyfourteen_setup
	add_action( 'after_setup_theme', 'twentyfourteen_setup' );
	
	/**
		* Adjust content_width value for image attachment template.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_content_width() {
		if ( is_attachment() && wp_attachment_is_image() ) {
			$GLOBALS['content_width'] = 810;
		}
	}
	add_action( 'template_redirect', 'twentyfourteen_content_width' );
	
	/**
		* Getter function for Featured Content Plugin.
		*
		* @since Twenty Fourteen 1.0
		*
		* @return array An array of WP_Post objects.
	*/
	function twentyfourteen_get_featured_posts() {
		/**
			* Filter the featured posts to return in Twenty Fourteen.
			*
			* @since Twenty Fourteen 1.0
			*
			* @param array|bool $posts Array of featured posts, otherwise false.
		*/
		return apply_filters( 'twentyfourteen_get_featured_posts', array() );
	}
	
	/**
		* A helper conditional function that returns a boolean value.
		*
		* @since Twenty Fourteen 1.0
		*
		* @return bool Whether there are featured posts.
	*/
	function twentyfourteen_has_featured_posts() {
		return ! is_paged() && (bool) twentyfourteen_get_featured_posts();
	}
	
	/**
		* Register three Twenty Fourteen widget areas.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_widgets_init() {
		require get_template_directory() . '/inc/widgets.php';
		register_widget( 'Twenty_Fourteen_Ephemera_Widget' );
		
		register_sidebar( array(
		'name'          => __( 'Social links', 'twentyfourteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Contact', 'twentyfourteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Footer col 1', 'twentyfourteen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Copyright', 'twentyfourteen' ),
		'id'            => 'sidebar-4',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Top', 'twentyfourteen' ),
		'id'            => 'sidebar-5',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Specialiteiten', 'twentyfourteen' ),
		'id'            => 'sidebar-6',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Specialiteiten Content', 'twentyfourteen' ),
		'id'            => 'sidebar-7',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Diensten', 'twentyfourteen' ),
		'id'            => 'sidebar-8',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Klanten', 'twentyfourteen' ),
		'id'            => 'sidebar-9',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Blog', 'twentyfourteen' ),
		'id'            => 'sidebar-10',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Optimizations', 'twentyfourteen' ),
		'id'            => 'sidebar-11',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Happy klanten', 'twentyfourteen' ),
		'id'            => 'sidebar-13',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Mid Content 1', 'twentyfourteen' ),
		'id'            => 'sidebar-14',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Overons content 1', 'twentyfourteen' ),
		'id'            => 'sidebar-12',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Overons content 2', 'twentyfourteen' ),
		'id'            => 'sidebar-15',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Overons content 3', 'twentyfourteen' ),
		'id'            => 'sidebar-16',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Overons mid content', 'twentyfourteen' ),
		'id'            => 'sidebar-17',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Home Overons', 'twentyfourteen' ),
		'id'            => 'sidebar-18',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'analyse content', 'twentyfourteen' ),
		'id'            => 'sidebar-19',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		register_sidebar( array(
		'name'          => __( 'Translator', 'twentyfourteen' ),
		'id'            => 'sidebar-20',
		'description'   => __( 'Main sidebar that appears on the left.', 'twentyfourteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
		) );
		
		
		
	}
	add_action( 'widgets_init', 'twentyfourteen_widgets_init' );
	
	/**
		* Register Lato Google font for Twenty Fourteen.
		*
		* @since Twenty Fourteen 1.0
		*
		* @return string
	*/
	function twentyfourteen_font_url() {
		$font_url = '';
		/*
			* Translators: If there are characters in your language that are not supported
			* by Lato, translate this to 'off'. Do not translate into your own language.
		*/
		if ( 'off' !== _x( 'on', 'Lato font: on or off', 'twentyfourteen' ) ) {
			$query_args = array(
			'family' => urlencode( 'Lato:300,400,700,900,300italic,400italic,700italic' ),
			'subset' => urlencode( 'latin,latin-ext' ),
			);
			$font_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
		}
		
		return $font_url;
	}
	
	/**
		* Enqueue scripts and styles for the front end.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_scripts() {
		// Add Lato font, used in the main stylesheet.
		wp_enqueue_style( 'twentyfourteen-lato', twentyfourteen_font_url(), array(), null );
		
		// Add Genericons font, used in the main stylesheet.
		wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.0.3' );
		
		// Load our main stylesheet.
		wp_enqueue_style( 'twentyfourteen-style', get_stylesheet_uri() );
		
		// Load the Internet Explorer specific stylesheet.
		wp_enqueue_style( 'twentyfourteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentyfourteen-style' ), '20131205' );
		wp_style_add_data( 'twentyfourteen-ie', 'conditional', 'lt IE 9' );
		
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
		
		if ( is_singular() && wp_attachment_is_image() ) {
			wp_enqueue_script( 'twentyfourteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20130402' );
		}
		
		if ( is_active_sidebar( 'sidebar-3' ) ) {
			wp_enqueue_script( 'jquery-masonry' );
		}
		
		if ( is_front_page() && 'slider' == get_theme_mod( 'featured_content_layout' ) ) {
			wp_enqueue_script( 'twentyfourteen-slider', get_template_directory_uri() . '/js/slider.js', array( 'jquery' ), '20131205', true );
			wp_localize_script( 'twentyfourteen-slider', 'featuredSliderDefaults', array(
			'prevText' => __( 'Previous', 'twentyfourteen' ),
			'nextText' => __( 'Next', 'twentyfourteen' )
			) );
		}
		
	}
	add_action( 'wp_enqueue_scripts', 'twentyfourteen_scripts' );
	
	/**
		* Enqueue Google fonts style to admin screen for custom header display.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_admin_fonts() {
		wp_enqueue_style( 'twentyfourteen-lato', twentyfourteen_font_url(), array(), null );
	}
	add_action( 'admin_print_scripts-appearance_page_custom-header', 'twentyfourteen_admin_fonts' );
	
	if ( ! function_exists( 'twentyfourteen_the_attached_image' ) ) :
	/**
		* Print the attached image with a link to the next attached image.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_the_attached_image() {
		$post                = get_post();
		/**
			* Filter the default Twenty Fourteen attachment size.
			*
			* @since Twenty Fourteen 1.0
			*
			* @param array $dimensions {
			*     An array of height and width dimensions.
			*
			*     @type int $height Height of the image in pixels. Default 810.
			*     @type int $width  Width of the image in pixels. Default 810.
			* }
		*/
		$attachment_size     = apply_filters( 'twentyfourteen_attachment_size', array( 810, 810 ) );
		$next_attachment_url = wp_get_attachment_url();
		
		/*
			* Grab the IDs of all the image attachments in a gallery so we can get the URL
			* of the next adjacent image in a gallery, or the first image (if we're
			* looking at the last image in a gallery), or, in a gallery of one, just the
			* link to that image file.
		*/
		$attachment_ids = get_posts( array(
		'post_parent'    => $post->post_parent,
		'fields'         => 'ids',
		'numberposts'    => -1,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order ID',
		) );
		
		// If there is more than 1 attachment in a gallery...
		if ( count( $attachment_ids ) > 1 ) {
			foreach ( $attachment_ids as $idx => $attachment_id ) {
				if ( $attachment_id == $post->ID ) {
					$next_id = $attachment_ids[ ( $idx + 1 ) % count( $attachment_ids ) ];
					break;
				}
			}
			
			// get the URL of the next image attachment...
			if ( $next_id ) {
				$next_attachment_url = get_attachment_link( $next_id );
			}
			
			// or get the URL of the first image attachment.
			else {
				$next_attachment_url = get_attachment_link( reset( $attachment_ids ) );
			}
		}
		
		printf( '<a href="%1$s" rel="attachment">%2$s</a>',
		esc_url( $next_attachment_url ),
		wp_get_attachment_image( $post->ID, $attachment_size )
		);
	}
	endif;
	
	if ( ! function_exists( 'twentyfourteen_list_authors' ) ) :
	/**
		* Print a list of all site contributors who published at least one post.
		*
		* @since Twenty Fourteen 1.0
	*/
	function twentyfourteen_list_authors() {
		$contributor_ids = get_users( array(
		'fields'  => 'ID',
		'orderby' => 'post_count',
		'order'   => 'DESC',
		'who'     => 'authors',
		) );
		
		foreach ( $contributor_ids as $contributor_id ) :
		$post_count = count_user_posts( $contributor_id );
		
		// Move on if user has not published a post (yet).
		if ( ! $post_count ) {
			continue;
		}
	?>
	
	<div class="contributor">
		<div class="contributor-info">
			<div class="contributor-avatar"><?php echo get_avatar( $contributor_id, 132 ); ?></div>
			<div class="contributor-summary">
				<h2 class="contributor-name"><?php echo get_the_author_meta( 'display_name', $contributor_id ); ?></h2>
				<p class="contributor-bio">
					<?php echo get_the_author_meta( 'description', $contributor_id ); ?>
				</p>
				<a class="button contributor-posts-link" href="<?php echo esc_url( get_author_posts_url( $contributor_id ) ); ?>">
					<?php printf( _n( '%d Article', '%d Articles', $post_count, 'twentyfourteen' ), $post_count ); ?>
				</a>
			</div><!-- .contributor-summary -->
		</div><!-- .contributor-info -->
	</div><!-- .contributor -->
	
	<?php
		endforeach;
	}
	endif;
	
	/**
		* Extend the default WordPress body classes.
		*
		* Adds body classes to denote:
		* 1. Single or multiple authors.
		* 2. Presence of header image except in Multisite signup and activate pages.
		* 3. Index views.
		* 4. Full-width content layout.
		* 5. Presence of footer widgets.
		* 6. Single views.
		* 7. Featured content layout.
		*
		* @since Twenty Fourteen 1.0
		*
		* @param array $classes A list of existing body class values.
		* @return array The filtered body class list.
	*/
	function twentyfourteen_body_classes( $classes ) {
		if ( is_multi_author() ) {
			$classes[] = 'group-blog';
		}
		
		if ( get_header_image() ) {
			$classes[] = 'header-image';
			} elseif ( ! in_array( $GLOBALS['pagenow'], array( 'wp-activate.php', 'wp-signup.php' ) ) ) {
			$classes[] = 'masthead-fixed';
		}
		
		if ( is_archive() || is_search() || is_home() ) {
			$classes[] = 'list-view';
		}
		
		if ( ( ! is_active_sidebar( 'sidebar-2' ) )
		|| is_page_template( 'page-templates/full-width.php' )
		|| is_page_template( 'page-templates/contributors.php' )
		|| is_attachment() ) {
			$classes[] = 'full-width';
		}
		
		if ( is_active_sidebar( 'sidebar-3' ) ) {
			$classes[] = 'footer-widgets';
		}
		
		if ( is_singular() && ! is_front_page() ) {
			$classes[] = 'singular';
		}
		
		if ( is_front_page() && 'slider' == get_theme_mod( 'featured_content_layout' ) ) {
			$classes[] = 'slider';
			} elseif ( is_front_page() ) {
			$classes[] = 'grid';
		}
		
		return $classes;
	}
	add_filter( 'body_class', 'twentyfourteen_body_classes' );
	
	/**
		* Extend the default WordPress post classes.
		*
		* Adds a post class to denote:
		* Non-password protected page with a post thumbnail.
		*
		* @since Twenty Fourteen 1.0
		*
		* @param array $classes A list of existing post class values.
		* @return array The filtered post class list.
	*/
	function twentyfourteen_post_classes( $classes ) {
		if ( ! post_password_required() && ! is_attachment() && has_post_thumbnail() ) {
			$classes[] = 'has-post-thumbnail';
		}
		
		return $classes;
	}
	add_filter( 'post_class', 'twentyfourteen_post_classes' );
	
	/**
		* Create a nicely formatted and more specific title element text for output
		* in head of document, based on current view.
		*
		* @since Twenty Fourteen 1.0
		*
		* @global int $paged WordPress archive pagination page count.
		* @global int $page  WordPress paginated post page count.
		*
		* @param string $title Default title text for current view.
		* @param string $sep Optional separator.
		* @return string The filtered title.
	*/
	function twentyfourteen_wp_title( $title, $sep ) {
		global $paged, $page;
		
		if ( is_feed() ) {
			return $title;
		}
		
		// Add the site name.
		$title .= get_bloginfo( 'name', 'display' );
		
		// Add the site description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) ) {
			$title = "$title $sep $site_description";
		}
		
		// Add a page number if necessary.
		if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
			$title = "$title $sep " . sprintf( __( 'Page %s', 'twentyfourteen' ), max( $paged, $page ) );
		}
		
		return $title;
	}
	add_filter( 'wp_title', 'twentyfourteen_wp_title', 10, 2 );
	
	// Implement Custom Header features.
	require get_template_directory() . '/inc/custom-header.php';
	
	// Custom template tags for this theme.
	require get_template_directory() . '/inc/template-tags.php';
	
	// Add Customizer functionality.
	require get_template_directory() . '/inc/customizer.php';
	
	/*
		* Add Featured Content functionality.
		*
		* To overwrite in a plugin, define your own Featured_Content class on or
		* before the 'setup_theme' hook.
	*/
	if ( ! class_exists( 'Featured_Content' ) && 'plugins.php' !== $GLOBALS['pagenow'] ) {
		require get_template_directory() . '/inc/featured-content.php';
	}
	function get_lat_long($address){
		
		$address = str_replace(" ", "+", $address);
		
		$json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=$address&sensor=false&region=$region");
		$json = json_decode($json);
		
		$lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
		$long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
		return $lat.','.$long;
	}
	function get_reviews_by_custom_search() {
		global $wpdb;
		//$category = preg_replace( '/[^0-9]/', '', $_GET['category'] );
		$category=$_GET['category'];
		//echo $category;exit;//only allow numbers
		//$address = preg_replace( '/^[0-9a-zA-Z-]/', '', $_GET['address'] ); // only allow letters, numbers and dashes...ie PG-13 and not PG#13
		//$length = preg_replace( '/[^0-9]/', '', $_GET['length'] ); // only allow numbers
		
		//if ($rating != '') {
		//$rating_sql = " AND wpostmeta.meta_key = 'rating' AND wpostmeta.meta_value = '$rating' ";
		// }
		if ($category != '') {
			$category_sql = "  AND wpostmeta.term_taxonomy_id = '$category' ";
		}
		// if ($length != '') {
		//$length_sql = " AND wpostmeta3.meta_key = 'length' AND wpostmeta3.meta_value = '$length' ";
		// }
		
		// This is based on a post from wordpress.org forums where the search terms were predefined in the query whereas mine pulls from a custom search form.  http://wordpress.org/support/topic/custom-fields-search#post-909384.
		$querystr = "
		SELECT DISTINCT wposts.*
		FROM $wpdb->posts wposts, $wpdb->term_relationships wpostmeta
		WHERE wposts.ID = wpostmeta.object_id
		" . $category_sql . "
		ORDER BY wposts.post_date DESC
		";
		$searched_posts = $wpdb->get_results($querystr);
		
		return $searched_posts;
		// By returning the seaerched posts, we can create a custom foreach loop on search.php
		
	}
	
	
	
	
	// Defer Javascripts
	// Defer jQuery Parsing using the HTML5 defer property
	if (!(is_admin() )) {
		function defer_parsing_of_js ( $url ) {
			if ( FALSE === strpos( $url, '.js' ) ) return $url;
			if ( strpos( $url, 'jquery.js' ) ) return $url;
			// return "$url' defer ";
			return "$url' defer onload='";
		}
		add_filter( 'clean_url', 'defer_parsing_of_js', 11, 1 );
	}
	
	function _remove_script_version( $src ){
		$parts = explode( '?ver', $src );
		return $parts[0];
	}
	add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
	add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );
	
	
	add_action('wp_ajax_setCookieData', 'setCookieData');
	add_action('wp_ajax_nopriv_setCookieData', 'setCookieData');
	
	/* function setCookieData() {
		$ip = $_SERVER['REMOTE_ADDR'];
		setcookie( 'site_ip', $ip, 3 * DAYS_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
		wp_die();
	} */
	function setCookieData() {
		global $wpdb;
		$now = new DateTime();
		$datesent=$now->format('Y-m-d H:i:s');
		$status = 1;
		$ip = $_SERVER['REMOTE_ADDR'];
		$sql = "SELECT COUNT(*) FROM wp_cookies WHERE cookie_ip='".$ip."'";
		$rowcount = $wpdb->get_var($sql);
		if($rowcount > 0){
			echo json_encode(array('status'=>'failed'));
		}
		else{
			$wpdb->insert('wp_cookies', array(
			'cookie_ip' => $ip,
			'time' => $datesent,
			'status' => $status,
			));
			setcookie( 'site_ip', $ip, 3 * DAYS_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
			echo json_encode(array('status'=>'success'));
		}
		wp_die();
	}
	
	add_action('wp_ajax_checkCookieData', 'checkCookieData');
	add_action('wp_ajax_nopriv_checkCookieData', 'checkCookieData');
	
	function checkCookieData() {
		global $wpdb;
		$ip = $_SERVER['REMOTE_ADDR'];
		$sql = "SELECT COUNT(*) FROM wp_cookies WHERE cookie_ip='".$ip."'";
		$rowcount = $wpdb->get_var($sql);
		if($rowcount > 0){
			echo json_encode(array('status'=>'failed'));
			setcookie( 'site_ip', $ip, 3 * DAYS_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );
		}
		else{
			echo json_encode(array('status'=>'success'));
		}
		wp_die();
	}
	
	add_filter('wpcf7_form_elements', function($content) {
		$content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);
		
		return $content;
	});
	
	// CUSTOM EXCERPT LENGTH
	function custom_excerpt_length($length) {
		/* $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') ||
			$_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
			$current_url=$protocol.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$site_link = get_site_url();
			if($current_url == $site_link){
			return 5;
			}
			else{
			return 15;
		} */
		return 15;
	}
	add_filter('excerpt_length', 'custom_excerpt_length');
	// CUSTEM EXCERPT ELLIPSES
	function new_excerpt_more($more) {
		return '...';
	}
	add_filter('excerpt_more', 'new_excerpt_more');
	
	
	add_action('wp_ajax_load_posts_by_ajax1', 'load_posts_by_ajax_callback1');
	add_action('wp_ajax_nopriv_load_posts_by_ajax1', 'load_posts_by_ajax_callback1');
	
	function load_posts_by_ajax_callback1(){
		$paged = $_POST['page'];
		$args = array(
		'posts_per_page' => 2,
		'paged' => $paged,
		'category_name' => 'blog',
		);
		$my_posts = new WP_QUERY($args);
		if($my_posts->have_posts()):
	while($my_posts->have_posts()): $my_posts->the_post(); ?>
	<div class="program_block col-lg-12 col-md-12 col-sm-12 col-xs-12 zero_pad">
		<div class="prgm_img col-lg-4 col-md-4 col-sm-4 col-xs-12 zero_pad">
			<?php
				$image_id = get_post_thumbnail_id($post->ID);
				$image_url = wp_get_attachment_image_src($image_id,'large', true);
			?>
			<!-- <a class="example-image-link" href="<?php echo $image_url['0'];?>" data-lightbox="example-1"> -->
			<img src="<?php bloginfo('template_directory'); ?>/timthumb.php?src=<?php echo $image_url['0'];?>&h=425&w=540&zc=1"/>
			<span class="search3"></span>
			<!--	</a> -->
		</div>
		<div class="prgm_txt col-lg-8 col-md-8 col-sm-8 col-xs-12 zero_pad">
			<h3><?php echo date("d M Y",strtotime(get_the_date())); ?></h3>
			<span class="icon">
				<span class='st_sharethis_large' displayText='ShareThis' st_url="<?php the_permalink(); ?>"></span>
				<span class='st__large' displayText=''></span>
			</span>
			<?php the_title( '<h2>', '</h2>' );?>
			<p><?php $con= get_the_content(); $con1=substr($con,0,300); echo wp_strip_all_tags($con1);?></p>
			<a href="<?php the_permalink(); ?>" class="active">Lees meer</a>
			
		</div>
	</div>
	<?php endwhile;
		wp_reset_postdata();
		endif;
		die();
	}
	
	
	add_action('wp_ajax_load_posts', 'load_posts');
	add_action('wp_ajax_nopriv_load_posts', 'load_posts');
	
	function load_posts(){
		$paged = $_POST['page'];
		$category = $_POST['category'];
		if(empty($category)){
			$category = "blog";
		}
		else{
			$category = "blog-2";
		}
		$args = array(
		'posts_per_page' => 2,
		'paged' => $paged,
		'category_name' => $category,
		'order'=>'asc'
		);
		$the_query = new WP_QUERY($args);
		if ( $the_query->have_posts() ) :
	while ( $the_query->have_posts() ) : $the_query->the_post();?>
	<div class="news_group">
		<div class="news_group_img">
			<?php the_post_thumbnail(); ?>
			<h6><?php the_time('d F Y'); ?></h6>
		</div>
		<div class="news_group_text">
			<h3><?php the_title(); ?></h3>
			<p><?php the_excerpt(); ?></p>
			<!--<p><?php remove_filter ('the_content', 'wpautop'); the_content(); ?></p>-->
			<a href="<?php the_permalink(); ?>">Lees meer</a>
		</div>
	</div>
	<?php endwhile;
		
		wp_reset_postdata();
		endif;
		die();
	}
	
	add_action('wp_ajax_load_faq', 'load_faq');
	add_action('wp_ajax_nopriv_load_faq', 'load_faq');
	
	function load_faq(){
	
		$count = $_POST['lastChar'];
		$paged = $_POST['page'];
		$category = $_POST['category'];
		if(empty($category)){
			$category = "faq";
		}
		else{
			$category = "faq-2";
		}
		$args = array(
		'posts_per_page' => 2,
		'paged' => $paged,
		'category_name' => $category,
		'order'=>'asc'
		);
		$the_query = new WP_QUERY($args);
		if ( $the_query->have_posts() ) : $count = $count + $paged;
	while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
	<div class="ques_conts">
		<h4><?php the_title(); ?></h4>
		<button type="button" class="buts" data-toggle="collapse" data-target="#ques_<?php echo $count; ?>"></button>
		<p id="ques_<?php echo $count; ?>" class="collapse"><?php remove_filter ('the_content', 'wpautop'); the_content(); ?></p>
	</div>
	<?php endwhile;
		
		wp_reset_postdata();
		endif;
		die();
	}
	
	add_action('wp_ajax_load_team', 'load_team');
	add_action('wp_ajax_nopriv_load_team', 'load_team');
	
	function load_team(){
		$paged = $_POST['page'];
		$category = $_POST['category'];
		if(empty($category)){
			$category = "team";
		}
		else{
			$category = "team-2";
		}
		$args = array(
		'posts_per_page' => 8,
		'paged' => $paged,
		'category_name' => $category,
		'order'=>'asc'
		);
		$the_query = new WP_QUERY($args);
		if ( $the_query->have_posts() ) :
	while ( $the_query->have_posts() ) : $the_query->the_post();?>
	<div class="col-xs-12 col-sm-3 col-md-3 col-lg3 col">
		<div class="member_group">
			<div class="member_img">
				<?php the_post_thumbnail(); ?>
			</div>
			<div class="member_text">
				<h2><?php the_title(); ?></br><span><?php echo do_shortcode('[jcf-value field="_role"]'); ?></span></h2>
				<p><?php the_content();?> </p>
				<div class="social_media">
					<ul class="list-inline">
						<li><a href="https://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="Share on Facebook."><div class="facebook"></div></a></li>
						<!--<li><a href="#"><div class="instagram"></div></a></li>-->
						<li><a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" title="Tweet this!"><div class="twitter"></div></a></li>
						<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>"><div class="pin"></div></a></li>
						<li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
						'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><div class="google"></div></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<?php endwhile;
		
		wp_reset_postdata();
		endif;
		die();
	}
	
	
	add_action('wp_ajax_subscribe', 'subscribe');
	add_action('wp_ajax_nopriv_subscribe', 'subscribe');
	function subscribe() {
		global $wpdb;
		$email = $_POST['email'];
		$now = new DateTime();
		$datesent=$now->format('Y-m-d H:i:s');
		$sql = "SELECT COUNT(*) FROM wp_subscribe WHERE subs_email='".$email."'";
		$rowcount = $wpdb->get_var($sql);
		if($rowcount > 0){
			echo json_encode(array('status'=>'failed'));
		}
		else{
			$wpdb->insert('wp_subscribe', array(
			'subs_email' => $email,
			'subs_date' => $datesent,
			));
			echo json_encode(array('status'=>'success'));
		}
		wp_die();
	}
	
	
	
	add_action('admin_menu', 'Subscribers_function');
	
	function Subscribers_function() {
		
		// This is the menu on the side
		add_menu_page(
		'Subscribers',
		'Subscribers',
		'manage_options',
		'myplugin-top-level-page'
		);
		
		// This is the first page that is displayed when the menu is clicked
		add_submenu_page(
		'myplugin-top-level-page',
		'MyPlugin Top Level Page',
		'MyPlugin Top Level Page',
		'manage_options',
		'myplugin-top-level-page',
		'myplugin_top_level_page_callback'
		);
		
		
	}
	
	function myplugin_top_level_page_callback() {
		
		global $wpdb;
	$results_from_db = $wpdb->get_results("SELECT * FROM wp_subscribe");?>
	
	<div class="wrap">
		<h1 class="wp-heading-inline">Subscribers</h1>
		<hr class="wp-header-end">
		
		<table class="wp-list-table widefat fixed striped posts">
			<thead>
				<tr>
					<th scope="col" id="sl_number" class="manage-column column-author">Number</th>
					<th scope="col" id="subs_email" class="manage-column column-categories">Email</th>
					<th scope="col" id="date" class="manage-column column-tags">Date</th>
				</tr>
			</thead>
			<tbody id="the-list">
				<?php $count=0; foreach ($results_from_db as $result) { $count++;?>
					
					<tr id="post-249" class="iedit author-self level-0 post-249 type-post status-publish format-standard hentry category-team">
						<td class="author column-author" data-colname="Author"><?php echo $count;?></td>
						<td class="categories column-categories" data-colname="Categories"><?php echo $result->subs_email;?></td>
						<td class="date column-date" data-colname="Date"><?php echo $result->subs_date;?></td>
					</tr>
				<?php }?>
			</tbody>
		</table>
	</div>
	<?php }
/*
function isa_add_cron_recurrence_interval( $schedules ) {
 
    $schedules['every_three_minutes'] = array(
            'interval'  => 30,
            'display'   => __( 'Every 3 Minutes', 'textdomain' )
    );
     
    return $schedules;
}
add_filter( 'cron_schedules', 'isa_add_cron_recurrence_interval' );

if ( ! wp_next_scheduled( 'your_three_minute_action_hook' ) ) {
    wp_schedule_event( time(), 'every_three_minutes', 'your_three_minute_action_hook' );
}

add_action('your_three_minute_action_hook', 'isa_test_cron_job_send_mail');
 
function isa_test_cron_job_send_mail() {
    $to = 'bvarunkumar14@gmail.com';
    $subject = 'Test my 3-minute cron job';
    $message = 'If you received this message, it means that your 3-minute cron job has worked! <img draggable="false" class="emoji" alt="🙂" src="https://s.w.org/images/core/emoji/2.4/svg/1f642.svg"> ';
 
    wp_mail( $to, $subject, $message );
 
}*/