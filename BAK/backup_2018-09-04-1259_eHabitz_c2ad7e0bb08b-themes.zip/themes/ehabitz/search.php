<?php
	/**
		* The template for displaying Search Results pages
		*
		* @package WordPress
		* @subpackage Twenty_Fourteen
		* @since Twenty Fourteen 1.0
	*/
get_template_part('home_header'); ?>
<section id="primary" class="content-area searchedResults">
	<div id="content" class="site-content" role="main">
		<?php if ( have_posts() ) : ?>
		<header class="page-header">
			<h3 class="page-title"><?php printf( __( 'Search Results for: %s', 'twentyfourteen' ), get_search_query() ); ?></h3>
		</header><!-- .page-header -->
		<?php
			// Start the Loop.
			while ( have_posts() ) : the_post();
			/*
				* Include the post format-specific template for the content. If you want to
				* use this in a child theme, then include a file called called content-___.php
				* (where ___ is the post format) and that will be used instead.
			*/
		//get_template_part( 'content', get_post_format() );?>
		<article id="post">
			<header class="entry-header">
				
				<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				<!--<?php if ( in_array( 'post_type', 'post') ) : ?>
				<?php
					endif;
					if ( is_single() ) :
					the_title( '<h2 class="entry-title">', '</h2>' );
					else :
						
						
					// the_title( '<h1 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h1>' );
					the_title( '<h1 class="entry-title">', '</h1>' );
					endif;
				?>-->
			</header><!-- .entry-header -->
			<?php if ( is_search() ) : ?>
			<div class="entry-summary">
				<?php the_excerpt(); ?>
			</div><!-- .entry-summary -->
			<?php else : ?>
			<div class="entry-content">
				<?php
					/* translators: %s: Name of current post */
					the_content( sprintf(
					__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'twentyfourteen' ),
					the_title( '<span class="screen-reader-text">', '</span>', false )
					) );
					wp_link_pages( array(
					'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentyfourteen' ) . '</span>',
					'after'       => '</div>',
					'link_before' => '<span>',
					'link_after'  => '</span>',
					) );
				?>
			</div><!-- .entry-content -->
			<?php endif; ?>
		</article>
		<?php 	endwhile;
			// Previous/next post navigation.
			twentyfourteen_paging_nav();
			else :
			// If no content, include the "No posts found" template.
			get_template_part( 'content', 'none' );
			endif;
		?>
	</div><!-- #content -->
</section><!-- #primary -->
<?php
	// get_sidebar( 'content' );
	// get_sidebar();
get_footer();