<?php
	/**
		* Template Name: blog Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); 
$language = $_GET['lang'];

?>
<div class="main_content news_page_conts">
	<div class="container">
		<input type="hidden" id="langValue" value="<?php echo $language; ?>"/>
		<!--<h1>Het laatste nieuws</h1>-->
		<h1><?php echo the_title(); ?></h1>
		<div class="news_groups">
			<?php //$the_query = new WP_Query( array('category_name' => 'blog')); ?>
			<?php  
			if($language == 'en'){
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'blog-2','post_type' => 'post','posts_per_page' => 2));
					}
					else{
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'blog','post_type' => 'post','posts_per_page' => 2));
					}
			?>
			<?php if ( $the_query->have_posts() ) : ?>
			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
			<div class="news_group">
				<div class="news_group_img">
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					<h6><?php the_time('d F Y'); ?></h6>
				</div>
				<div class="news_group_text">
					<h3><?php the_title(); ?></h3>
					<p><?php the_excerpt(); ?></p>
					<!--<p><?php remove_filter ('the_content', 'wpautop'); the_content(); ?></p>-->
					<a href="<?php the_permalink(); ?>">Lees meer</a>
				</div>
			</div>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
			<?php else : ?>
			<p><?php __('No Posts'); ?></p>
			<?php endif; ?>
			<div class="posts"></div>
			<div class="loading" style="display:none">
				<img src="<?php echo  get_template_directory_uri()?>/images/loading.GIF" alt="loading" >
			</div>
		</div>
	</div>
</div>
<?php //$category = get_category(6);
	if($language == 'en'){
		$category = get_category(16);
	}else{
		$category = get_category(17);
	}
	$blog_count = $category->category_count; ?>	
<Script type="text/javascript">
	
	
	var count = 2;
	var total_post = "<?php echo $blog_count; ?>";
	
	var total_page = total_post/2;
	var intvalue = Math.round(total_page);
	// $('.news_groups').on('scroll', function() {
        // if($(this).scrollTop() + $(this).outerHeight() >= $(this)[0].scrollHeight) {
            // console.log('end reached');
        // }
    // })
	$(window).scroll(function(){
		//alert($(document).height()+'-' +$(window).height());
		//console.log($(document).height() - $(window).height());
		if  ($(window).scrollTop() == $(document).height() - $(window).height()){
		// if ($(window).scrollTop() >= ($(window).height() - $(document).height())*0.7){	
		// fetch(count);
		// count++;
			if(count > intvalue)
			{
				return true;
			}
			else
			{
				fetch(count);
				count++;
			}
		}
	});
	
	function fetch(pageNumber)
	{
		var categoryName = $("#langValue").val();
		var data = {'action' : 'load_posts','page' : pageNumber, 'category' : categoryName};
		// $.post(ajaxurl, data, function(response){
			// $('.posts').append(response);
		// });
		$(".loading").css('display','block');
		$.ajax({
			url: ajaxurl,
			type:   'post',
			data: data,
			success: function(response) {
				$('.posts').append(response);
			},
			complete: function(){
				$(".loading").css('display','none');
			}
			
		});
	}
</script>
<?php get_footer(); ?>