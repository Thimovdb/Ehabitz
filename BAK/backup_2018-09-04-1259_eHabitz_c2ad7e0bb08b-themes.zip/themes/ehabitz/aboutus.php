<?php
	/**
		* Template Name: aboutus Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header');
$language = $_GET['lang'];
?>
<div class="main_content over_ons_conts">
	<div class="container">
		<!--<h1>Over Ons</h1>-->
		<h1><?php echo the_title(); ?></h1>
	</div>
	<div class="overons_cont1">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont1_text">
						<img src="<?php echo  get_template_directory_uri()?>/images/ons.png">
						
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=0' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=0' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<h2><?php the_title(); ?></h2>
						<p><?php the_content(); ?></p>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						
						
						<?php //if ( ! dynamic_sidebar( 'sidebar-12' ) ) : ?>
						<?php
							//the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php //endif; // end sidebar widget area ?>
						
						<!--<h2>Wij begrijpen de complexe online marketing wereld!</h2>
						<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. </p>
						<p>Sed scelerisque eros vitae turpis facilisis dignissim. Etiam ac arcu porttitor, rutrum nibh nec, sollicitudin libero. Donec dolor odio, luctus ac tellus eu.</p>
						<p>Donec non tempor augue. Vestibulum rhoncus turpis sed orci lobortis interdum. Duis posuere mollis turpis in tempor.</p>-->
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont1_img">
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=0' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=0' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<?php the_post_thumbnail(); ?>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/onscont1.png">-->
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="overons_cont2">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont2_img">
						
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=1' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=1' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<?php the_post_thumbnail(); ?>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/onscont2.png">-->
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont2_text">
						
						<img src="<?php echo  get_template_directory_uri()?>/images/ons.png">
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=1' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=1' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<h2><?php the_title(); ?></h2>
						<p><?php the_content(); ?></p>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						
						<?php //if ( ! dynamic_sidebar( 'sidebar-15' ) ) : ?>
						<?php
							//the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php //endif; // end sidebar widget area ?>
						<!--<h2>No-Nonse internet marketingresultaat gericht!</h2>
						<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna.Donec non tempor augue. Vestibulum rhoncus turpis sed orci lobortis interdum. Duis posuere mollis turpis in tempor.</p>
						<p>Nam accumsan dignissim lacinia. Aenean efficitur leo nec ex molestie tincidunt. Sed sit amet nisl in purus facilisis fringilla vel quis odio. Cras iaculis scelerisque consectetur. Donec mi magna, luctus vitae porta a, hendrerit vel leo. In hac habitasse platea dictumst.</p>-->
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="website_analiys">
		<div class="container">
			<?php if ( ! dynamic_sidebar( 'sidebar-17' ) ) : ?>
			<?php
				the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
			?>
			<?php endif; // end sidebar widget area ?>
			<!--<h3>Gratis website analyse</h3>
			<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. Curabitur scelerisque urna metus, vel luctus elit dapibus id. Vestibulum pretium quam in aliquet malesuada. Cras iaculis magna vitae ex accumsan eleifend.</p>
			<button type="button" class="buts">Lees meer</button>-->
			<a href="<?php echo get_site_url()?>/analyse" class="buts">Lees meer</a>
		</div>
	</div>
	<div class="overons_cont3">
		<div class="container">
			<div class="row ">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont3_text">
					<img src="<?php echo  get_template_directory_uri()?>/images/ons.png">
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=2' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=2' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<h2><?php the_title(); ?></h2>
						<p><?php the_content(); ?></p>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						
						<?php //if ( ! dynamic_sidebar( 'sidebar-16' ) ) : ?>
						<?php
							//the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
						?>
						<?php //endif; // end sidebar widget area ?>
						
						<!--<h2>Gericht te werk gaan, dat is aleen flinke besparing</h2>
						<p>Nullam ligula massa, faucibus eget lacinia at, facilisis vel nibh. Maecenas a venenatis mi, sit amet ultricies magna. </p>
						<p>Sed scelerisque eros vitae turpis facilisis dignissim. Etiam ac arcu porttitor, rutrum nibh nec, sollicitudin libero. Donec dolor odio, luctus ac tellus eu.</p>
						<p>Donec non tempor augue. Vestibulum rhoncus turpis sed orci lobortis interdum. Duis posuere mollis turpis in tempor.</p>-->
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
					<div class="cont3_img">
						<?php
						// the query
							if($language == 'en'){
								$the_query = new WP_Query( 'showposts=1&category_name=overons-2&order=asc&offset=2' );
							}
							else{
								$the_query = new WP_Query( 'showposts=1&category_name=overons&order=asc&offset=2' );
							}
						?>
						<?php if ( $the_query->have_posts() ) : $count = 0;?>
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
						<?php the_post_thumbnail(); ?>
						<?php endwhile; ?>
						<?php wp_reset_postdata(); ?>
						<?php else : ?>
						<p><?php __('No Posts'); ?></p>
						<?php endif; ?>
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/onscont3.png">-->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>