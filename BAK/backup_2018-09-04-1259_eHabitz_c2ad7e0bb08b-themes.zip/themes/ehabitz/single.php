<?php get_template_part('home_header');  ?>
<div class="main_content news_details_page_conts">
	<div class="">
		<div class="news_deatail_img">
			<!--<img src="<?php echo  get_template_directory_uri()?>/images/news_detailimg.png" alt="img">-->
			<?php the_post_thumbnail(); ?>
		</div>
		<div class="container">
			<div class="news_deatail_text">
				<?php
					if(have_posts()){
					while(have_posts()):the_post(); ?>
					<h6><?php the_time('d F Y'); ?></h6>
					<h1><?php the_title();?></h1>
					<p><?php the_content();?></p>
					<div class="social_media_news">
						<h4>Deel op :</h4>
						<ul class="list-inline">
							<li><a href="https://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>&amp;p=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>" title="Share on Facebook."><div class="facebook"></div></a></li>
									<!--<li><a href="#"><div class="instagram"></div></a></li>-->
									<li><a href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?> - <?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>" title="Tweet this!"><div class="twitter"></div></a></li>
									<li><a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>"><div class="pin"></div></a></li>
									<li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,
							'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><div class="google"></div></a></li>
						</ul>
					</div>
					<?php endwhile;
					}?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>