<?php
	/**
		* Template Name: contact Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage twenthestad
		* @since twenthestad
	*/
get_template_part('home_header'); ?>
<div class="main_content about_us_conts">
	<div class="container">
		<h1>Contact</h1>
	</div>
	<div class="submit_details">
		<div class="container">
			<div class="shad">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
						<div class="add_ress">
							<h4>Contact</h4>
							<?php if ( ! dynamic_sidebar( 'sidebar-2' ) ) : ?>
							<?php
								the_widget( 'Twenty_Eleven_Ephemera_Widget', '', array( 'before_title' => '<h3 class="widget-title">', 'after_title' => '</h3>' ) );
							?>
							<?php endif; // end sidebar widget area ?>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col">
						<div class="enter_details">
							<?php $language = $_GET['lang'];
							if($language == "en"){ ?>
							<h4>Send us an e-mail</h4>
							<?}else{ ?>
							<h4>Stuur ons een e-mail</h4>
							<?php }?>
							<div class="form-group">
							<?php if($language == "en"){
								echo do_shortcode('[contact-form-7 id="499" title="Contact english"]');
							 }else{
								echo do_shortcode('[contact-form-7 id="214" title="Contact"]');
								}?>
								<?php //echo do_shortcode('[contact-form-7 id="214" title="Contact"]'); ?>
								<!--<input class="Myinput"type="text" name="sub" placeholder="Naam">
									<input class="Myinput"type="text" name="sub" placeholder="Onderwerp">
									<input class="Myinput"type="text" name="sub" placeholder="Email">
									<input class="Myinput"type="text" name="sub" placeholder="Telefoon">
									<textarea placeholder="Schrijf uw bericht..."></textarea>
								<button type="button" class="buts">verstuur</button>-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="locationfind" id="map_canvas">
			
			<?php echo do_shortcode('[gmap-embed id="449"]');?>
			<?php //echo do_shortcode('[put_wpgm id=2]');?>
			<!--<img src="<?php echo  get_template_directory_uri()?>/images/locationfind.png">-->
		</div>
	</div>
</div>
<script src="<?php echo bloginfo('template_url');?>/js/formValidator/jquery.validate.js"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/jquery.validationEngine.js?v=1"></script>
<script src="<?php bloginfo('template_url');?>/js/formValidator/languages/jquery.validationEngine-en.js?v=1"></script>
<script type="text/javascript">
	jQuery( document ).ready(function( $ ) {
		$(".wpcf7-form").validate({
			rules:{
				'your-name': {
					required: true
				},
				'your-message' : {
					required: true
				},
				'your-email':{
					required: true,
					email: true
				},
				'your-phone':{
					required: true,
					number:true
				} ,
				'your-subject':{
					required: true,
					//number:true
				} ,
			},
			messages: {
				'your-name': { required	 : <?php echo json_encode("Vul uw naam in.");?> },
				'your-subject': { required	 : <?php echo json_encode("Vul uw ondewerp in.");?> },
				'your-message': { required	 : <?php echo json_encode("Vul uw bericht in.");?> },
				'your-phone':{ required	 : <?php echo json_encode("Vul een telefoonnummer in.");?>,number:<?php echo json_encode("Enkel nummers zijn toegestaan.");?>},
				
				'your-email': { required :<?php echo json_encode("Vul een e-mailadres in.");?> ,
					email	 :<?php echo json_encode("Vul een correct e-mailadres in.");?>
				},
			},
		});
	});
</script>
<?php get_footer(); ?>