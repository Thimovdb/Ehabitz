<?php
	/**
		* Template Name: service Template
		* Description: A Page Template that adds a sidebar to pages
		*
		* @package WordPress
		* @subpackage appetite
		* @since appetite
	*/
get_template_part('home_header'); 

$language = $_GET['lang'];

?>
<div class="main_content service_page_conts">
	<div class="container">
		<!--<h1>Diensten</h1>-->
		<h1><?php echo the_title(); ?></h1>
		<div class="service_page_conts_groups">
			<div class="row">
				<?php
					// the query
					
					if($language == 'en'){
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten-2','showposts' => 4));
					}
					else{
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten','showposts' => 4));
					}
					//$the_query = new WP_Query( 'showposts=4&category_name=diensten&order=asc' );
				?>
				<?php if ( $the_query->have_posts() ) : $count=0;?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
				<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
					<div class="service_page_conts_group">
						<div class="group_img_serv">
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/serv_page_cont_group<?php echo $count;?>.png" alt="service_page_conts_groupimg">-->
						<?php the_post_thumbnail(); ?>
						</div>
						<h3><?php the_title(); ?></h3>
						<!--<p><?php the_content();?></p>-->
						<span class="serv_cont"><?php the_excerpt(); ?></span>
						<a href="<?php echo get_site_url()?>/service-detail/?id=<?php echo get_the_ID() ?>" class="buts">LEES MEER</a>
						<!--<input type="text" value="<?php echo get_the_ID() ?>"/>-->
					</div>
				</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php else : ?>
				<p><?php __('No Posts'); ?></p>
				<?php endif; ?>
			</div>
			<div class="row">
				<?php
					// the query
					//$the_query = new WP_Query( 'showposts=4&category_name=diensten&order=asc&offset=4' );
					if($language == 'en'){
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten-2','showposts' => 4, 'offset'=>4));
					}
					else{
						$the_query = $the_query = new WP_Query( array('order'=>'asc','category_name' => 'diensten','showposts' => 4, 'offset'=>4));
					}
				?>
				<?php if ( $the_query->have_posts() ) : $count=4;?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); $count++;?>
				<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
					<div class="service_page_conts_group">
						<div class="group_img_serv">
						<!--<img src="<?php echo  get_template_directory_uri()?>/images/serv_page_cont_group<?php echo $count;?>.png" alt="service_page_conts_groupimg">-->
						<?php the_post_thumbnail(); ?>
						</div>
						<h3><?php the_title(); ?></h3>
						<!--<p><?php the_content();?></p>-->
						<span class="serv_cont"><?php the_excerpt(); ?></span>
						<a href="<?php echo get_site_url()?>/service-detail/?id=<?php echo get_the_ID() ?>" class="buts">LEES MEER</a>
						<!--<button type="button" class="buts">LEES MEER</button>-->
						<!--<input type="text" value="<?php echo get_the_ID() ?>"/>-->
					</div>
				</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
				<?php else : ?>
				<p><?php __('No Posts'); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<!--<button type="button" class="buts1">al onze diensten</button>-->
		<a href="<?php echo get_site_url()?>/service-detail/" class="buts1">al onze diensten</a>
	</div>
</div>
<?php get_footer(); ?>